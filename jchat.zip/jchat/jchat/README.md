jchat
=====

Basic Chat coded with Nodejs and Socket.io

You can see the server code [here](https://github.com/serdnah2/jchat_server)

[Demo](http://projects.innovacenter.co/jchat) page 
